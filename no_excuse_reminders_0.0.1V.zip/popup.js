const STORAGE_KEY = 'reminders_v1';

/** @typedef {{id:string,title:string,when:number,enabled:boolean,completed:boolean}} Reminder */

const editView = document.getElementById('view-edit');
const ul = document.getElementById('reminders');
const empty = document.getElementById('empty');
const form = document.getElementById('form');
const titleInput = document.getElementById('title');
const dateInput = document.getElementById('date');
const timeInput = document.getElementById('time');

// Edit form elements
const editForm = document.getElementById('editForm');
const editTitleInput = document.getElementById('editTitle');
const editDateInput = document.getElementById('editDate');
const editTimeInput = document.getElementById('editTime');
const editCancelBtn = document.getElementById('editCancel');

// Modal elements
const confirmModal = document.getElementById('confirmModal');
const confirmMessage = document.getElementById('confirmMessage');
const confirmCancel = document.getElementById('confirmCancel');
const confirmDelete = document.getElementById('confirmDelete');

let reminderToDelete = null;
let reminderToEdit = null;

// Initialize form with current date/time
function initializeForm() {
	const now = new Date();
	now.setSeconds(0, 0);
	now.setMinutes(now.getMinutes() + 5 - (now.getMinutes() % 5));
	dateInput.value = now.toISOString().slice(0, 10);
	timeInput.value = now.toTimeString().slice(0, 5);
	titleInput.focus();
}

// Add event listeners for quick action buttons
document.addEventListener('DOMContentLoaded', () => {
	const quickButtons = document.querySelectorAll('.quick-btn');
	quickButtons.forEach(btn => {
		btn.addEventListener('click', handleQuickAction);
	});
});

function handleQuickAction(e) {
	const minutes = parseInt(e.target.dataset.minutes);
	if (!minutes) return;
	
	// Get the task title from the input field
	const title = titleInput.value.trim();
	if (!title) {
		// If no title, just set the time and focus back to title input
		const now = new Date();
		now.setMinutes(now.getMinutes() + minutes);
		now.setSeconds(0, 0);
		
		dateInput.value = now.toISOString().slice(0, 10);
		timeInput.value = now.toTimeString().slice(0, 5);
		titleInput.focus();
		return;
	}
	
	// If there's a title, automatically create the reminder
	const now = new Date();
	now.setMinutes(now.getMinutes() + minutes);
	now.setSeconds(0, 0);
	
	const when = now.getTime();
	const reminder = { id: crypto.randomUUID(), title, when, enabled: true, completed: false };
	
	// Create the reminder
	createReminder(reminder);
	
	// Add visual feedback
	e.target.style.transform = 'scale(0.95)';
	setTimeout(() => {
		e.target.style.transform = '';
	}, 150);
}

async function createReminder(reminder) {
	const all = await getAll();
	all.unshift(reminder);
	await saveAll(all);
	await schedule(reminder);
	
	// Reset form and focus back to the title input
	titleInput.value = '';
	titleInput.focus();
	
	// Re-render the list
	await render();
}

editCancelBtn.addEventListener('click', () => {
	showList();
});

form.addEventListener('submit', async (e) => {
	e.preventDefault();
	const title = titleInput.value.trim();
	if (!title) return;
	
	const when = parseInputsToEpoch(dateInput.value, timeInput.value);
	const reminder = { id: crypto.randomUUID(), title, when, enabled: true, completed: false };
	
	// Create the reminder using the shared function
	await createReminder(reminder);
});

editForm.addEventListener('submit', async (e) => {
	e.preventDefault();
	if (!reminderToEdit) return;
	
	const title = editTitleInput.value.trim();
	if (!title) return;
	
	const when = parseInputsToEpoch(editDateInput.value, editTimeInput.value);
	
	// Update the reminder
	reminderToEdit.title = title;
	reminderToEdit.when = when;
	
	// If the reminder was completed, reset it since we're editing
	if (reminderToEdit.completed) {
		reminderToEdit.completed = false;
		reminderToEdit.enabled = true;
	}
	
	// Cancel existing alarm and schedule new one
	await cancelAlarm(reminderToEdit.id);
	await schedule(reminderToEdit);
	
	// Save changes
	await saveUpdate(reminderToEdit);
	
	// Reset form and show list
	editTitleInput.value = '';
	reminderToEdit = null;
	showList();
	await render();
});

function showEditForm(reminder){
	editView.classList.add('active');
	
	reminderToEdit = reminder;
	
	// Prefill the form with current values
	editTitleInput.value = reminder.title;
	const reminderDate = new Date(reminder.when);
	editDateInput.value = reminderDate.toISOString().slice(0,10);
	editTimeInput.value = reminderDate.toTimeString().slice(0,5);
	
	setTimeout(() => editTitleInput.focus(), 50);
}

function showList(){
	editView.classList.remove('active');
}

async function getAll(){
	const { [STORAGE_KEY]: val } = await chrome.storage.local.get(STORAGE_KEY);
	return Array.isArray(val) ? val : [];
}

async function saveAll(items){
	await chrome.storage.local.set({ [STORAGE_KEY]: items });
}

function parseInputsToEpoch(dateStr, timeStr){
	const [y,m,d] = dateStr.split('-').map(Number);
	const [hh,mm] = timeStr.split(':').map(Number);
	return new Date(y, m-1, d, hh, mm, 0, 0).getTime();
}

function formatWhen(ts){
	const d = new Date(ts);
	return d.toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' });
}

function createCard(reminder){
	const li = document.createElement('li');
	li.className = 'card' + (reminder.completed ? ' done' : '');
	li.draggable = true;
	li.dataset.id = reminder.id;

	// Drag and drop event listeners
	li.addEventListener('dragstart', handleDragStart);
	li.addEventListener('dragover', handleDragOver);
	li.addEventListener('drop', handleDrop);
	li.addEventListener('dragend', handleDragEnd);

	const handle = document.createElement('div');
	handle.className = 'drag-handle';
	handle.textContent = '≡';
	li.appendChild(handle);

	const checkbox = document.createElement('input');
	checkbox.type = 'checkbox';
	checkbox.className = 'checkbox';
	checkbox.checked = reminder.completed;
	checkbox.addEventListener('change', async () => {
		reminder.completed = checkbox.checked;
		if (reminder.completed) reminder.enabled = false;
		await saveUpdate(reminder);
		await cancelAlarm(reminder.id);
		await render();
	});
	li.appendChild(checkbox);

	const content = document.createElement('div');
	content.className = 'task-content';
	content.style.display = 'flex';
	content.style.flexDirection = 'column';
	content.style.gap = '2px';
	content.style.cursor = 'pointer';
	content.style.flex = '1';
	
	// Make the content area clickable for editing
	content.addEventListener('click', () => {
		showEditForm(reminder);
	});

	const title = document.createElement('div');
	title.className = 'title';
	title.textContent = reminder.title;
	content.appendChild(title);

	const meta = document.createElement('div');
	meta.className = 'meta';
	meta.textContent = formatWhen(reminder.when);
	content.appendChild(meta);

	li.appendChild(content);

	const toggle = document.createElement('input');
	toggle.type = 'checkbox';
	toggle.className = 'switch';
	toggle.checked = reminder.enabled;
	toggle.addEventListener('change', async () => {
		reminder.enabled = toggle.checked;
		if (reminder.enabled && !reminder.completed) {
			await schedule(reminder);
		} else {
			await cancelAlarm(reminder.id);
		}
		await saveUpdate(reminder);
		await render();
	});
	li.appendChild(toggle);

	// Add delete button
	const deleteBtn = document.createElement('button');
	deleteBtn.className = 'delete-btn';
	deleteBtn.innerHTML = '×';
	deleteBtn.title = 'Delete reminder';
	deleteBtn.addEventListener('click', async () => {
		showDeleteConfirmation(reminder);
	});
	li.appendChild(deleteBtn);

	return li;
}

async function saveUpdate(updated){
	const all = await getAll();
	const idx = all.findIndex(r => r.id === updated.id);
	if (idx !== -1) {
		all[idx] = updated;
		await saveAll(all);
	}
}

async function schedule(reminder){
	if (!reminder.enabled || reminder.completed) return;
	if (reminder.when <= Date.now()) return;
	await chrome.alarms.create(`reminder:${reminder.id}`, { when: reminder.when });
}

async function cancelAlarm(id){
	await chrome.alarms.clear(`reminder:${id}`);
}

async function render(){
	const items = await getAll();
	ul.innerHTML = '';
	if (!items.length) {
		empty.style.display = 'block';
	} else {
		empty.style.display = 'none';
	}
	for (const it of items){
		ul.appendChild(createCard(it));
	}
}

async function deleteReminder(id){
	const all = await getAll();
	const filtered = all.filter(r => r.id !== id);
	await saveAll(filtered);
	await cancelAlarm(id);
}

// Modal functions
function showDeleteConfirmation(reminder) {
	reminderToDelete = reminder;
	confirmMessage.textContent = `Are you sure you want to delete "${reminder.title}"?`;
	confirmModal.classList.add('active');
}

function hideDeleteConfirmation() {
	confirmModal.classList.remove('active');
	reminderToDelete = null;
}

// Modal event listeners
confirmCancel.addEventListener('click', hideDeleteConfirmation);
confirmDelete.addEventListener('click', async () => {
	if (reminderToDelete) {
		await deleteReminder(reminderToDelete.id);
		await render();
		hideDeleteConfirmation();
	}
});

// Close modal when clicking outside
confirmModal.addEventListener('click', (e) => {
	if (e.target === confirmModal) {
		hideDeleteConfirmation();
	}
});

// Drag and drop functions
let draggedElement = null;

function handleDragStart(e) {
	draggedElement = this;
	this.classList.add('dragging');
	e.dataTransfer.effectAllowed = 'move';
	e.dataTransfer.setData('text/html', this.outerHTML);
}

function handleDragOver(e) {
	e.preventDefault();
	e.dataTransfer.dropEffect = 'move';
	
	if (this === draggedElement) return;
	
	const rect = this.getBoundingClientRect();
	const midY = rect.top + rect.height / 2;
	
	if (e.clientY < midY) {
		this.classList.add('drag-above');
		this.classList.remove('drag-below');
	} else {
		this.classList.add('drag-below');
		this.classList.remove('drag-above');
	}
}

function handleDrop(e) {
	e.preventDefault();
	
	if (this === draggedElement) return;
	
	// Remove drag indicators
	this.classList.remove('drag-above', 'drag-below');
	
	const draggedId = draggedElement.dataset.id;
	const targetId = this.dataset.id;
	
	if (draggedId === targetId) return;
	
	// Reorder the reminders
	reorderReminders(draggedId, targetId, e.clientY < this.getBoundingClientRect().top + this.getBoundingClientRect().height / 2);
}

function handleDragEnd(e) {
	this.classList.remove('dragging');
	
	// Remove all drag indicators
	document.querySelectorAll('.card').forEach(card => {
		card.classList.remove('drag-above', 'drag-below');
	});
	
	draggedElement = null;
}

async function reorderReminders(draggedId, targetId, insertAbove) {
	const all = await getAll();
	const draggedIndex = all.findIndex(r => r.id === draggedId);
	const targetIndex = all.findIndex(r => r.id === targetId);
	
	if (draggedIndex === -1 || targetIndex === -1) return;
	
	const [draggedReminder] = all.splice(draggedIndex, 1);
	
	let newIndex;
	if (insertAbove) {
		newIndex = targetIndex;
	} else {
		newIndex = targetIndex + 1;
	}
	
	all.splice(newIndex, 0, draggedReminder);
	
	await saveAll(all);
	await render();
}

await render();
initializeForm(); 