Place your clock.png here (512x512 works; will be resized in CSS).
